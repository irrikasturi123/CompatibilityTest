import { ChartsComponent } from './shared/charts/charts.component';
import { SigninComponent } from './shared/signin/signin.component';
import { JoininComponent } from './shared/joinin/joinin.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MobilesGuard } from './services/mobiles.guard';


const routes: Routes = [
  { path : '' , component : HomeComponent  },
  { path : 'about' , component : AboutComponent},
  { path : 'register' , component : JoininComponent},
  { path : 'login' , component : SigninComponent},
  { path : 'charts' , component : ChartsComponent},
  { path : 'mobiles', loadChildren : './modules/mobile.module#MobileModule', canActivate : [MobilesGuard] },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
