import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MobileService {

  mobUrl = "http://localhost:3000/MobileProducts";
  userUrl = "http://localhost:3000/Users";
  mobile;
  thisPage;

  constructor(private http : HttpClient) { }

  getMobiles():Observable<any>{
    return this.http.get(this.mobUrl)
  }
  getMobile(id):Observable<any>{
    return this.http.get(this.mobUrl+"/"+id);
  }

  addMobile(mob):any{
    return this.http.post(this.mobUrl,mob);
  }
  deleteMobile(id): Observable<any>{
    return this.http.delete(this.mobUrl+"/"+id);
  }

  updateMobile(mob){
    return this.http.put(this.mobUrl+"/"+mob.id,mob);
  }

  setSession(key,value){
    sessionStorage.setItem(key,value)
  }
  getSession(key){
    return sessionStorage.getItem(key)
  }
  setLocal(key,value){
    localStorage.setItem(key,value)
  }
  getLocal(key){
    return localStorage.getItem(key)
  }
}
