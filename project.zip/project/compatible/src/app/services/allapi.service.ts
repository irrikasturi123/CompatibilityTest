import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class AllapiService {
  userUrl = "http://localhost:3000/Users";

  constructor(private http:HttpClient) { }
  insertData(input):Observable<any>{
    return this.http.post<any>(this.userUrl,input);
  }
  getData():Observable<any> {
    return this.http.get<any>(this.userUrl);
  }

  login(uname,pass):Observable<any> {
    return this.http.get<any>(this.userUrl+"?emailid="+uname+"&password="+pass);
  }
}
