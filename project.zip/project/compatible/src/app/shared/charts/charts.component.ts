import { MobileService } from './../../services/mobile.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})
export class ChartsComponent implements OnInit {

  multi: any[] = [];
  view: any[] = [900, 400];

  // options
  showXAxis: boolean = true;
  showYAxis: boolean = true;
  gradient: boolean = false;
  showLegend: boolean = true;
  legendPosition: string = 'below';
  showXAxisLabel: boolean = true;
  yAxisLabel: string = 'Mobile';
  showYAxisLabel: boolean = true;
  xAxisLabel = 'No. of Views';

  colorScheme = {
    domain: ['#5AA454', '#C7B42C', '#AAAAAA']
  };
  schemeType: string = 'linear';
  gotData: boolean = false;
  // multiple = [
  //   {
  //     name : "Germany",
  //     series: [
  //       {
  //         "name": "2010",
  //         "value": 7300000
  //       }
  //     ]
  //   }
  // ];

  constructor(private mobserv: MobileService) {
    // Object.assign(this, { multi });
  }

  ngOnInit(){
    this.gotData = true
    this.mobserv.getMobiles().subscribe(
      res => {
        // this.multi = res;
        let multis = {
          name : "",
          series: [
            {
              name: "",
              value: null
            }
          ]
        };
        for(let i= 0;i < res.length;i++)
        {
          multis = {
            name : "",
            series: [
              {
                name: "",
                value: null
              }
            ]
            };
          multis.name = res[i].brand+" "+res[i].model;
          // multis.series[0].name = res[i].model
          multis.series[0].value = res[i].views
          this.multi.push(multis);
        }
        this.multi = [...this.multi]
        // this.multi = this.multiple
      }
    )
  }

  onSelect(data): void {
    console.log('Item clicked', JSON.parse(JSON.stringify(data)));
  }

  onActivate(data): void {
    console.log('Activate', JSON.parse(JSON.stringify(data)));
  }

  onDeactivate(data): void {
    console.log('Deactivate', JSON.parse(JSON.stringify(data)));
  }

}
