import { HeadersComponent } from './../headers/headers.component';
import { MobileService } from './../../services/mobile.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AllapiService } from 'src/app/services/allapi.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  loginUserData = {};
  LoginForm: FormGroup;
  data: any;
  responseData: Array<object>;
  submitted: boolean;


  constructor( private router: Router,
    private formBuilder: FormBuilder,
    private myservice: AllapiService,
    private mobserv: MobileService) { }

  ngOnInit() {
    this.LoginForm = this.formBuilder.group({
     emailid: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{5,}')]],

    });
  }
  get f() { return this.LoginForm.controls; }

  onSubmit() {
    this.submitted = true
    if (this.LoginForm.valid) {
      console.log(this.responseData);
      console.log(this.LoginForm.value);
      let data = this.LoginForm.value;

      this.myservice.login(data.emailid, data.password).subscribe(res => {
        console.log(res);
        if(res.length > 0){
          localStorage.setItem("userId",res[0].id);
          this.router.navigate(['/mobiles']);
        } else {
          // this.mobserv.setLocal("userId",'');
          localStorage.removeItem("userId");
          console.log('Incorrect Email id or Password!')
          this.openDialog();
        }
      });
    }
    else{
      return;
    }
  }
    openDialog(){
      Swal.fire
      ({
        title: "Incorrect Email id or Password!",
        text: "Please try again",
        icon: "error"
      }).then((result)=> {
        if(result) {
          this.router.navigate(['/login']);
        }
      })
      
  }
  }
 



