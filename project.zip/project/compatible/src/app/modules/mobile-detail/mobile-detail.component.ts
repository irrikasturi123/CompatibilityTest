import { MobileService } from './../../services/mobile.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-detail',
  templateUrl: './mobile-detail.component.html',
  styleUrls: ['./mobile-detail.component.css']
})
export class MobileDetailComponent implements OnInit {

  id;
  mobile = {
    "id": null,
    "brand": "",
    "model": "",
    "views" : null,
    "ram": {
      "size": null,
      "price": null
    },
    "img_URL":
      "https://i.gadgets360cdn.com/products/large/1551217932_635_samsung_galaxy_m30.jpg?downsize=*:420&output-quality=80"
  };
  getData: boolean = false;
  constructor(public mobserv : MobileService) { }

  ngOnInit(){
    this.id = this.mobserv.getSession('mobId')
    this.getProd(this.id)
    
  }

  getProd(id){
    this.getData = true
    this.mobserv.getMobile(id).subscribe(
      res => {
        this.mobile = res;
        console.log("product--->",this.mobile)
        this.mobile.views++
        this.mobserv.updateMobile(this.mobile).subscribe(
        res=> {
          console.log("Increment",res)
        }
       )
      }
      
    )
    
  }

}
