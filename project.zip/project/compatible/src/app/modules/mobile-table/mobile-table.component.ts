import { Router } from '@angular/router';
import { MobileService } from './../../services/mobile.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-table',
  templateUrl: './mobile-table.component.html',
  styleUrls: ['./mobile-table.component.css'],
})
export class MobileTableComponent implements OnInit {
  filterPrice: any = [];
  filterRam: any = [];
  signedIn = false;
  isBrandCollapsed = false;
  isRAMCollapsed = false;
  isPriceCollapsed = false;
  isbrandchecked = false;
  brands = ['Black', 'Tan', 'Brown', 'Grey', 'Stylish', 'Style', 'Zivana'];
  prices = [
    '0-4999',
    '5000-9999',
    '10000-19999',
    '20000-29999',
    '30000-49999',
    '50000-999999',
  ];
  // rams = ['1', '2', '4', '6', '8', '12', '16'];
  filterBrand = [];
  products :any = [];
  // = [
  //   {
  //     id: 1,
  //     brand: 'samsung',
  //     model: 'M30',
  //     ram: {
  //       size: 8,
  //       price: 18999,
  //     },
  //     img_URL:
  //       'https://i.gadgets360cdn.com/products/large/1551217932_635_samsung_galaxy_m30.jpg?downsize=*:420&output-quality=80',
  //   },
  //   {
  //     id: 1,
  //     brand: 'apple',
  //     model: 'iphone SE',
  //     ram: {
  //       size: 4,
  //       price: 38999,
  //     },
  //     img_URL:
  //       'https://i.gadgets360cdn.com/products/large/1551217932_635_samsung_galaxy_m30.jpg?downsize=*:420&output-quality=80',
  //   },
  //   {
  //     id: 1,
  //     brand: 'oneplus',
  //     model: '8',
  //     ram: {
  //       size: 6,
  //       price: 42999,
  //     },
  //     img_URL:
  //       'https://i.gadgets360cdn.com/products/large/1551217932_635_samsung_galaxy_m30.jpg?downsize=*:420&output-quality=80',
  //   },
  // ];
  filterproducts: any[];
  getMobiles: boolean = false;

  constructor( private mobserv: MobileService,
    private router : Router) {}

  ngOnInit(): void {
    this.getAllMobiles();
    this.mobserv.setSession('thisPage', 'false')
    this.mobserv.setSession('isedit', 'false')
    this.filterproducts = this.products
    this.mobserv.mobile = {
      id : null,
      brand: '',
      model:'',
      ram :{
        size : null,
        price : null,
      },
      img_URL : ''
     }
  }
  getAllMobiles(){
    this.getMobiles = true;
    this.mobserv.getMobiles().subscribe(
      res=>{
        this.products = res;
        this.filterproducts = this.products
      }
    )
  }
  details(pro){
    // this.prodServ.id = pro.id;
    this.mobserv.setSession('mobId',pro.id)
    this.router.navigateByUrl(`/detail/${pro.brand}`);
  }

  edit(mob){
    this.mobserv.setSession('isedit',true)
    this.mobserv.mobile = mob;
    this.router.navigateByUrl('/mobiles/Add')
  }
  delete(mob){
    mob.brand = mob.brand.toUpperCase();
    if(confirm(`Would you like to delete ${mob.brand} ${mob.model}?`)){
      this.mobserv.deleteMobile(mob.id).subscribe(res=>{
        this.router.navigateByUrl('/mobiles')
      })
    }
    else{
      this.router.navigateByUrl('/mobiles')
    }
  }

  check(e, type, ev) {
    console.log(
      `${type}-->${e},event---->${ev.currentTarget.checked},type--->${type}`
    );
    let isChecked = ev.currentTarget.checked;
    if ((type == 'brand')) {
      if (isChecked) {
        this.filterBrand.push(e);
      } 
      else {
        this.filterBrand.forEach((value,index) => {
          if(value == e){
            this.filterBrand.splice(index,1);
          }
        })
      }
    } 
    else if ((type == 'price')) {
      if (isChecked) {
        this.filterPrice.push(e);
      } 
      else {
        this.filterPrice.forEach((value,index) => {
          if(value == e){
            this.filterPrice.splice(index,1);
          }
        })
      }
    } 
    else if ((type == 'ram')) {
      if (isChecked) {
        this.filterRam.push(e);
      } 
      else {
        this.filterRam.forEach((value,index) => {
          if(value == e){
            this.filterRam.splice(index,1);
          }
        })
      }
    }
    // console.log("filter Brand Array-->",this.filterBrand)
      this.filterproducts = this.filterCheckbox();
  }
  // filterbrand(){
  
  // }
  prodSearch(e,s){
    console.log(`Event---->`,e)
    console.log("Search-->",s.value)
    this.filterproducts = this.transform(this.products,s.value)
  }
  transform(items: any[], searchText: string): any[] {
    if (!items) {
      return [];
    }
    if (!searchText) {
      return items;
    }
    searchText = searchText.toLowerCase();
  
    return items.filter(it => {
      return it.brand.toLowerCase().includes(searchText);
    });
  }
  filterCheckbox() : any[]{
    let filterDup = []
    if(this.filterBrand.length != 0){
      for(let i = 0;i < this.filterBrand.length; i++){
        let it = this.filterBrand[i].toLowerCase();
        this.products.forEach(val => {
          if(it == val.brand.toLowerCase()){
            filterDup.push(val)
          }
        })
      }
    }
    // else if(this.filterBrand.length == 0){
    //   filterDup = this.products
    // }
    if(this.filterPrice.length != 0){
      // let filterDup1 = filterDup
      for(let i = 0;i < this.filterPrice.length; i++){
        let it = {
          firstVal : +this.filterPrice[i].split("-",2)[0],
          secondVal : +this.filterPrice[i].split("-",2)[1]
        }
        // this.filterPrice[i];
        console.log("range-->",it)
        this.products.forEach(val => {
          if(it.firstVal <= val.ram.price && it.secondVal >= val.ram.price){
            filterDup.push(val)
          }
        })
      }
    }
    // else if(this.filterBrand.length == 0 && this.filterPrice.length == 0){
    //   filterDup = this.products
    // }
    if(this.filterRam.length != 0){
      // filterDup = []
      for(let i = 0;i < this.filterRam.length; i++){
        let it = this.filterRam[i];
        this.products.forEach(val => {
          if(it == val.ram.size){
            filterDup.push(val)
          }
        })
      }
    }
    else if(this.filterBrand.length == 0 && this.filterPrice.length == 0 && this.filterRam.length == 0){
      filterDup = this.products
    }
    return filterDup
  }
  ngAfterViewInit($event) {
    console.log($event);
  }
}


// @Pipe({ name: 'searchFilter' })
// export class FilterPipe implements PipeTransform {
//   /**
//    * Transform
//    *
//    * @param {any[]} items
//    * @param {string} searchText
//    * @returns {any[]}
//    */
  
// }