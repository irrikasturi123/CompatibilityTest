import { MobileService } from './../../services/mobile.service';
import { AfterViewChecked, Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-mobile',
  templateUrl: './add-mobile.component.html',
  styleUrls: ['./add-mobile.component.css'],
})
export class AddMobileComponent implements OnDestroy {
  AddMobileForm: FormGroup;
  submitted = false;
  isdefault: boolean = false;
  url;
  mobile = {
    id : null,
    brand: '',
    model:'',
    views : null,
    ram :{
      // size : null,
      price : null,
    },
    img_URL : ''
   }
   isupdate = 'false';

  constructor(
    private formBuilder: FormBuilder,
    private mobserv: MobileService,
    private router: Router
  ) {}

  ngOnInit() {
    this.isdefault = false;
    this.mobile = sessionStorage.getItem('thisPage') == 'true' ? this.mobserv.thisPage : this.mobile
    this.url = "https://ae01.alicdn.com/kf/H59f339373abb40e48eb2c72d29d02899Y/Peach-Milk-Women-Cute-Backpack-Pink-Bookbag-Mochila-Mini-Bagpack-Cartoon-Travel-Backpack-Nylon-School-Bags.jpg_q50.jpg";
    if(this.mobserv.getSession('isedit') == 'true'){
      this.mobile = this.mobserv.mobile
      this.isupdate = 'true'
    }
    this.AddMobileForm = this.formBuilder.group({
      brand: [this.mobile.brand ? this.mobile.brand : '', Validators.required],
      model: [this.mobile.model ? this.mobile.model : '', Validators.required],
      // ram: [this.mobile.ram.size ? this.mobile.ram.size : '', Validators.required],
      price: [this.mobile.ram.price ? this.mobile.ram.price : '', Validators.required],
      url: [this.mobile.img_URL ? this.mobile.img_URL : this.url, Validators.required],
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.AddMobileForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.AddMobileForm.invalid) {
      return;
    }

    // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.AddMobileForm.value))
    if(this.isupdate != "true"){
      let data = {
        brand: this.AddMobileForm.value.brand,
        model: this.AddMobileForm.value.model,
        ram: {
          // size: this.AddMobileForm.value.ram,
          price: this.AddMobileForm.value.price,
        },
        img_URL: this.AddMobileForm.value.url,
        views : 0
      };
      this.mobserv.addMobile(data).subscribe((res) => {
        console.log('response--->', res);
        this.mobile = res ? res : this.mobile;
        // this.AddMobileForm = this.formBuilder.group({
        //   brand: ['', Validators.required],
        //   model: ['', Validators.required],
        //   ram: ['', Validators.required],
        //   price: ['', Validators.required],
        //   url: ['', Validators.required],
        // });
        if(this.mobile.id != null && this.mobile){
          if(confirm(`Do you want to add another product?`)){
            this.ngOnInit();
          }
          else{
            this.router.navigateByUrl('/mobiles');
          }
        }
      });
    }
    else{
      // this.mobile.views++
      let data = {
        id : this.mobile.id != null ? this.mobile.id : null,
        brand: this.AddMobileForm.value.brand ? this.AddMobileForm.value.brand : this.mobile.brand,
        model: this.AddMobileForm.value.model ? this.AddMobileForm.value.model : this.mobile.model,
        ram: {
          // size: this.AddMobileForm.value.ram ? this.AddMobileForm.value.ram : this.mobile.ram.size,
          price: this.AddMobileForm.value.price ? this.AddMobileForm.value.price : this.mobile.ram.price,
        },
        img_URL: this.AddMobileForm.value.url ? this.AddMobileForm.value.url : this.mobile.img_URL,
        views : this.mobile.views != null ? this.mobile.views : 0
      };
      this.mobserv.updateMobile(data).subscribe(
        res => {
          console.log('response after update--->', res);
          if(this.mobile.id != null && this.mobile){
            if(confirm(`Do you want to add another product?`)){
              this.ngOnInit();
            }
            else{
              this.router.navigateByUrl('/mobiles');
            }
          }
        }
      )
    }
  }

  ngOnDestroy(){
    if(this.AddMobileForm.invalid || this.AddMobileForm.untouched){
     var con = confirm("Redirecting to other page will not save your data. Do you wish to Redirect?")
     if(con == true){
       console.log(con)
     }
     else{
       sessionStorage.setItem('thisPage','true');
       this.mobserv.thisPage = this.AddMobileForm.value
       this.router.navigateByUrl('/Add')
     }
    }
  }
}
