import { MobileService } from './services/mobile.service';
import { AfterViewChecked, AfterViewInit, Component, OnChanges, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements AfterViewChecked{
  constructor(private mobserv : MobileService){}
  title = 'capstoneProj';
  isLogin = false;
  // = this.mobserv.getLocal("userId") ? true : false
  
  ngAfterViewChecked(){
    this.isLogin = this.mobserv.getLocal("userId") ? true : false
  }
}
